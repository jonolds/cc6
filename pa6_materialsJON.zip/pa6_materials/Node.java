import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.hadoop.io.Text;

public class Node {

	public static enum Color { WHITE, GRAY, BLACK };

	private int id, cost;
	private List<Integer> edges = new ArrayList<Integer>();
	private List<Integer> weights = new ArrayList<Integer>();
	private Color color = Color.WHITE;

	public Node(String str) {
		String[] map = str.split("\t");
		String key = map[0], value = map[1];
		String[] tokens = value.split("\\|");

		this.id = Integer.parseInt(key);

		for (String s : tokens[0].split(",")) {
			if (s.length() > 0)
				edges.add(Integer.parseInt(s));
		}
		
		for (String s : tokens[1].split(",")) {
			if (s.length() > 0)
				weights.add(Integer.parseInt(s));
		}
		
		if (tokens[2].equals("Integer.MAX_VALUE"))
			this.cost = Integer.MAX_VALUE;
		else
			this.cost = Integer.parseInt(tokens[2]);
		
		this.color = Color.valueOf(tokens[3]);

	}

	public Node(int id) { this.id = id; }
	public int getId() { return this.id; }
	
	public List<Integer> getEdges() { return this.edges; }
	public void setEdges(List<Integer> edges) { this.edges = edges; }

	public List<Integer> getWeights() { return this.weights; }
	public void set(List<Integer> weights) { this.weights = weights; }
	
	public int getCost() { return this.cost; }
	public void setCost(int cost) { this.cost = cost; }

	public Color getColor() { return this.color; }
	public void setColor(Color color) { this.color = color; }

	public Text getLine() {
		StringBuffer s = new StringBuffer();
		s.append(edges.stream().map(x->String.valueOf(x)).collect(Collectors.joining(",")));
		s.append("|");
		s.append(weights.stream().map(x->String.valueOf(x)).collect(Collectors.joining(",")));
		s.append("|");
		if (this.cost < Integer.MAX_VALUE)
			s.append(this.cost).append("|");
		else
			s.append("Integer.MAX_VALUE").append("|");
		s.append(color.toString());
		return new Text(s.toString());
	}
}